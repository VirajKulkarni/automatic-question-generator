This document describes the contents of the split for Neural Question Generation Dataset.


The structure of this release is:
|---QG
|    |---dev
|    |---test
|    |---test_sample
|    |---train
|---raw

It contains the following data:

1. Raw data is extracted from the Stanford Question Answering Dataset (SQuAD), which is in the folder named raw.
Three files are included:
Train set: train.txt
Development set: dev.txt.shuffle.dev
Test set: dev.txt.shuffle.test

The data format is:
TokenizedInputSentence \t AnswerStartAndEndPosition \t ParsingTreeOfInputSentence \t PoSTagOfInputSentence \t NERTagsOfInputSentence \t TokenizedQuestion \t UntokenizedInputSentence \t AnswerStartCharIndex \t Answer \t UntokenizedQuestion

2. QG folder contains the processed train, dev and test sets in the corresponding folders.
Each of them has six files: 
input sentence file ends with ".source.txt";
output question file ends with ".target.txt";
BIO sequence file ends with ".bio";
NER sequence file ends with ".ner";
PoS sequence file ends with ".pos";
word case sequence file ends with ".case"

3. The folder named test_sample is a random held-out from the test set, and the human raters labeled first 200 lines of it.
